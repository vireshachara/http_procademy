export class Product {
    pName:string;
    desc:string;
    price:number;
    id? : string;
    date : string;
} 